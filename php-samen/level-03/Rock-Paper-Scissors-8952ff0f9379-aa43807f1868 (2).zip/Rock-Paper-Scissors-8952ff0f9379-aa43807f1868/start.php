<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Steen, Papier, Schaar</title>
</head>
<body>
    <h1>Steen, Papier, Schaar</h1>
    <h2>Kies een modus:</h2>
        <a href="game2.php">Tegen een andere speler</a> <br>
        <a href="game.php">Tegen de computer</a>
</body>
</html>
